﻿using System;
using System.Windows.Forms;

namespace PharmacyOrderApp
{
    public partial class FormResumen : Form
    {
        private string resumenPedido;

        public FormResumen(string resumen)
        {
            InitializeComponent();
            resumenPedido = resumen;
        }

        private void FormResumen_Load(object sender, EventArgs e)
        {
            lblResumen.Text = resumenPedido;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Pedido enviado");
            this.Close();
        }
    }
}
