using System;
using System.Windows.Forms;

namespace PharmacyOrderApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            // Limpiar todos los campos
            txtNombreMedicamento.Clear();
            cmbTipoMedicamento.SelectedIndex = -1;
            txtCantidad.Clear();
            rbCofarma.Checked = false;
            rbEmpsephar.Checked = false;
            rbCemefar.Checked = false;
            chkPrincipal.Checked = false;
            chkSecundaria.Checked = false;
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            // Validar datos
            if (string.IsNullOrWhiteSpace(txtNombreMedicamento.Text) || !txtNombreMedicamento.Text.All(char.IsLetterOrDigit))
            {
                MessageBox.Show("Ingrese un nombre de medicamento v�lido.");
                return;
            }

            if (cmbTipoMedicamento.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccione un tipo de medicamento.");
                return;
            }

            if (!int.TryParse(txtCantidad.Text, out int cantidad) || cantidad <= 0)
            {
                MessageBox.Show("Ingrese una cantidad v�lida.");
                return;
            }

            if (!rbCofarma.Checked && !rbEmpsephar.Checked && !rbCemefar.Checked)
            {
                MessageBox.Show("Seleccione un distribuidor.");
                return;
            }

            if (!chkPrincipal.Checked && !chkSecundaria.Checked)
            {
                MessageBox.Show("Seleccione al menos una sucursal.");
                return;
            }

            // Mostrar resumen del pedido
            string distribuidor = rbCofarma.Checked ? "Cofarma" : rbEmpsephar.Checked ? "Empsephar" : "Cemefar";
            string sucursales = chkPrincipal.Checked ? "Calle de la Rosa n.28" : "";
            if (chkSecundaria.Checked)
            {
                sucursales += (sucursales != "" ? " y " : "") + "Calle Alcazabilla n.3";
            }

            string resumen = $"Pedido al distribuidor {distribuidor}\n\n" +
                             $"{cantidad} unidades del {cmbTipoMedicamento.SelectedItem} {txtNombreMedicamento.Text}\n\n" +
                             $"Para la farmacia situada en {sucursales}";

            // Abrir nueva ventana con el resumen
            FormResumen formResumen = new FormResumen(resumen);
            formResumen.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
