﻿namespace PharmacyOrderApp
{
    partial class FormResumen
    {
        private System.ComponentModel.IContainer components = null;
        private Label lblResumen;
        private Button btnCancelar;
        private Button btnEnviar;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblResumen = new Label();
            btnCancelar = new Button();
            btnEnviar = new Button();
            SuspendLayout();
            // 
            // lblResumen
            // 
            lblResumen.Location = new Point(12, 9);
            lblResumen.Name = "lblResumen";
            lblResumen.Size = new Size(360, 100);
            lblResumen.TabIndex = 0;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(297, 112);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(75, 23);
            btnCancelar.TabIndex = 1;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // btnEnviar
            // 
            btnEnviar.Location = new Point(216, 112);
            btnEnviar.Name = "btnEnviar";
            btnEnviar.Size = new Size(75, 23);
            btnEnviar.TabIndex = 2;
            btnEnviar.Text = "Enviar";
            btnEnviar.UseVisualStyleBackColor = true;
            btnEnviar.Click += btnEnviar_Click;
            // 
            // FormResumen
            // 
            ClientSize = new Size(384, 194);
            Controls.Add(btnEnviar);
            Controls.Add(btnCancelar);
            Controls.Add(lblResumen);
            Name = "FormResumen";
            Load += FormResumen_Load;
            ResumeLayout(false);
        }
    }
}
