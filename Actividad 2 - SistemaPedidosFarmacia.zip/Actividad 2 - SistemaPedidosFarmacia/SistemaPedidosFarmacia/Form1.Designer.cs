﻿namespace PharmacyOrderApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtNombreMedicamento;
        private System.Windows.Forms.ComboBox cmbTipoMedicamento;
        private System.Windows.Forms.TextBox txtCantidad;
        private System.Windows.Forms.GroupBox groupBoxDistribuidores;
        private System.Windows.Forms.RadioButton rbCofarma;
        private System.Windows.Forms.RadioButton rbEmpsephar;
        private System.Windows.Forms.RadioButton rbCemefar;
        private System.Windows.Forms.CheckBox chkPrincipal;
        private System.Windows.Forms.CheckBox chkSecundaria;
        private System.Windows.Forms.Button btnBorrar;
        private System.Windows.Forms.Button btnConfirmar;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            txtNombreMedicamento = new TextBox();
            cmbTipoMedicamento = new ComboBox();
            txtCantidad = new TextBox();
            groupBoxDistribuidores = new GroupBox();
            rbCofarma = new RadioButton();
            rbEmpsephar = new RadioButton();
            rbCemefar = new RadioButton();
            chkPrincipal = new CheckBox();
            chkSecundaria = new CheckBox();
            btnBorrar = new Button();
            btnConfirmar = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            groupBoxDistribuidores.SuspendLayout();
            SuspendLayout();
            // 
            // txtNombreMedicamento
            // 
            txtNombreMedicamento.Location = new Point(247, 17);
            txtNombreMedicamento.Name = "txtNombreMedicamento";
            txtNombreMedicamento.Size = new Size(200, 27);
            txtNombreMedicamento.TabIndex = 0;
            // 
            // cmbTipoMedicamento
            // 
            cmbTipoMedicamento.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbTipoMedicamento.FormattingEnabled = true;
            cmbTipoMedicamento.Items.AddRange(new object[] { "Analgésico", "Analéptico", "Anestésico", "Antiácido", "Antidepresivo", "Antibiótico" });
            cmbTipoMedicamento.Location = new Point(247, 57);
            cmbTipoMedicamento.Name = "cmbTipoMedicamento";
            cmbTipoMedicamento.Size = new Size(200, 28);
            cmbTipoMedicamento.TabIndex = 1;
            // 
            // txtCantidad
            // 
            txtCantidad.Location = new Point(247, 97);
            txtCantidad.Name = "txtCantidad";
            txtCantidad.Size = new Size(200, 27);
            txtCantidad.TabIndex = 2;
            // 
            // groupBoxDistribuidores
            // 
            groupBoxDistribuidores.Controls.Add(rbCofarma);
            groupBoxDistribuidores.Controls.Add(rbEmpsephar);
            groupBoxDistribuidores.Controls.Add(rbCemefar);
            groupBoxDistribuidores.Location = new Point(247, 152);
            groupBoxDistribuidores.Name = "groupBoxDistribuidores";
            groupBoxDistribuidores.Size = new Size(200, 100);
            groupBoxDistribuidores.TabIndex = 3;
            groupBoxDistribuidores.TabStop = false;
            groupBoxDistribuidores.Text = "Distribuidores";
            // 
            // rbCofarma
            // 
            rbCofarma.AutoSize = true;
            rbCofarma.Location = new Point(10, 20);
            rbCofarma.Name = "rbCofarma";
            rbCofarma.Size = new Size(87, 24);
            rbCofarma.TabIndex = 0;
            rbCofarma.TabStop = true;
            rbCofarma.Text = "Cofarma";
            rbCofarma.UseVisualStyleBackColor = true;
            // 
            // rbEmpsephar
            // 
            rbEmpsephar.AutoSize = true;
            rbEmpsephar.Location = new Point(10, 45);
            rbEmpsephar.Name = "rbEmpsephar";
            rbEmpsephar.Size = new Size(104, 24);
            rbEmpsephar.TabIndex = 1;
            rbEmpsephar.TabStop = true;
            rbEmpsephar.Text = "Empsephar";
            rbEmpsephar.UseVisualStyleBackColor = true;
            // 
            // rbCemefar
            // 
            rbCemefar.AutoSize = true;
            rbCemefar.Location = new Point(10, 70);
            rbCemefar.Name = "rbCemefar";
            rbCemefar.Size = new Size(86, 24);
            rbCemefar.TabIndex = 2;
            rbCemefar.TabStop = true;
            rbCemefar.Text = "Cemefar";
            rbCemefar.UseVisualStyleBackColor = true;
            // 
            // chkPrincipal
            // 
            chkPrincipal.AutoSize = true;
            chkPrincipal.Location = new Point(227, 291);
            chkPrincipal.Name = "chkPrincipal";
            chkPrincipal.Size = new Size(88, 24);
            chkPrincipal.TabIndex = 4;
            chkPrincipal.Text = "Principal";
            chkPrincipal.UseVisualStyleBackColor = true;
            // 
            // chkSecundaria
            // 
            chkSecundaria.AutoSize = true;
            chkSecundaria.Location = new Point(352, 291);
            chkSecundaria.Name = "chkSecundaria";
            chkSecundaria.Size = new Size(104, 24);
            chkSecundaria.TabIndex = 5;
            chkSecundaria.Text = "Secundaria";
            chkSecundaria.UseVisualStyleBackColor = true;
            // 
            // btnBorrar
            // 
            btnBorrar.Location = new Point(227, 326);
            btnBorrar.Name = "btnBorrar";
            btnBorrar.Size = new Size(96, 33);
            btnBorrar.TabIndex = 6;
            btnBorrar.Text = "Borrar";
            btnBorrar.UseVisualStyleBackColor = true;
            btnBorrar.Click += btnBorrar_Click;
            // 
            // btnConfirmar
            // 
            btnConfirmar.Location = new Point(352, 326);
            btnConfirmar.Name = "btnConfirmar";
            btnConfirmar.Size = new Size(104, 33);
            btnConfirmar.TabIndex = 7;
            btnConfirmar.Text = "Confirmar";
            btnConfirmar.UseVisualStyleBackColor = true;
            btnConfirmar.Click += btnConfirmar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(56, 24);
            label1.Name = "label1";
            label1.Size = new Size(185, 20);
            label1.TabIndex = 8;
            label1.Text = "Nombre del Medicamento";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(56, 65);
            label2.Name = "label2";
            label2.Size = new Size(156, 20);
            label2.TabIndex = 9;
            label2.Text = "Tipo de Medicamento";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(56, 104);
            label3.Name = "label3";
            label3.Size = new Size(69, 20);
            label3.TabIndex = 10;
            label3.Text = "Cantidad";
            // 
            // Form1
            // 
            ClientSize = new Size(550, 388);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtNombreMedicamento);
            Controls.Add(cmbTipoMedicamento);
            Controls.Add(txtCantidad);
            Controls.Add(groupBoxDistribuidores);
            Controls.Add(chkPrincipal);
            Controls.Add(chkSecundaria);
            Controls.Add(btnBorrar);
            Controls.Add(btnConfirmar);
            Name = "Form1";
            Text = "Formulario de Pedido";
            Load += Form1_Load;
            groupBoxDistribuidores.ResumeLayout(false);
            groupBoxDistribuidores.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        private Label label1;
        private Label label2;
        private Label label3;
    }
}
